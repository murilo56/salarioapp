// autonomous_services_page.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AutonomousService {
  DateTime date;
  String description;
  String client;
  double agreedValue;
  double receivedValue;
  String paymentMethod;
  String paymentStatus;
  String category;
  String observations;

  AutonomousService({
    required this.date,
    required this.description,
    required this.client,
    required this.agreedValue,
    required this.receivedValue,
    required this.paymentMethod,
    required this.paymentStatus,
    required this.category,
    required this.observations,
  });
}

class AutonomousServicesPage extends StatefulWidget {
  @override
  _AutonomousServicesPageState createState() => _AutonomousServicesPageState();
}

class _AutonomousServicesPageState extends State<AutonomousServicesPage> {
  List<AutonomousService> services = [];

  @override
  Widget build(BuildContext context) {
    double totalAgreed = services.fold(0, (sum, item) => sum + item.agreedValue);
    double totalReceived = services.fold(0, (sum, item) => sum + item.receivedValue);
    double totalPending = totalAgreed - totalReceived;

    return Scaffold(
      appBar: AppBar(
        title: Text('Serviços Autônomos'),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Data')),
                  DataColumn(label: Text('Descrição')),
                  DataColumn(label: Text('Cliente')),
                  DataColumn(label: Text('Valor R\$')),
                  DataColumn(label: Text('Status')),
                ],
                rows: services.map((service) => DataRow(cells: [
                  DataCell(Text(DateFormat('dd/MM/yyyy').format(service.date))),
                  DataCell(Text(service.description)),
                  DataCell(Text(service.client)),
                  DataCell(Text(service.agreedValue.toStringAsFixed(2))),
                  DataCell(Chip(
                    label: Text(service.paymentStatus),
                    backgroundColor: _getStatusColor(service.paymentStatus),
                  )),
                ])).toList(),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Total combinado: R\$ ${totalAgreed.toStringAsFixed(2)}'),
                Text('Total recebido: R\$ ${totalReceived.toStringAsFixed(2)}'),
                Text('Total pendente: R\$ ${totalPending.toStringAsFixed(2)}'),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: _showAddServiceDialog,
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Pago':
        return Colors.green;
      case 'Parcial':
        return Colors.orange;
      case 'Pendente':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  void _showAddServiceDialog() {
    DateTime selectedDate = DateTime.now();
    final _descriptionController = TextEditingController();
    final _clientController = TextEditingController();
    final _agreedValueController = TextEditingController();
    final _receivedValueController = TextEditingController();
    final _observationsController = TextEditingController();
    String paymentMethod = 'Dinheiro';
    String paymentStatus = 'Pendente';
    String category = 'Outros';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Adicionar Serviço'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Descrição'),
              ),
              TextFormField(
                controller: _clientController,
                decoration: InputDecoration(labelText: 'Cliente'),
              ),
              TextFormField(
                controller: _agreedValueController,
                decoration: InputDecoration(labelText: 'Valor combinado'),
                keyboardType: TextInputType.number,
              ),
              TextFormField(
                controller: _receivedValueController,
                decoration: InputDecoration(labelText: 'Valor recebido'),
                keyboardType: TextInputType.number,
              ),
              TextFormField(
                controller: _observationsController,
                decoration: InputDecoration(labelText: 'Observações'),
              ),
              DropdownButton<String>(
                value: paymentMethod,
                onChanged: (value) => setState(() => paymentMethod = value!),
                items: ['Dinheiro', 'Cartão', 'Pix'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              ),
              DropdownButton<String>(
                value: paymentStatus,
                onChanged: (value) => setState(() => paymentStatus = value!),
                items: ['Pago', 'Parcial', 'Pendente'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              ),
              DropdownButton<String>(
                value: category,
                onChanged: (value) => setState(() => category = value!),
                items: ['Outros', 'Tatuagem', 'Design', 'Consulta'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: Text('Cancelar'),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: Text('Salvar'),
            onPressed: () {
              setState(() {
                services.add(AutonomousService(
                  date: selectedDate,
                  description: _descriptionController.text,
                  client: _clientController.text,
                  agreedValue: double.tryParse(_agreedValueController.text) ?? 0.0,
                  receivedValue: double.tryParse(_receivedValueController.text) ?? 0.0,
                  paymentMethod: paymentMethod,
                  paymentStatus: paymentStatus,
                  category: category,
                  observations: _observationsController.text,
                ));
              });
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}
